import os
from flask import Flask, render_template, request

# Print to confirm exact paths
print("Current Working Directory:", os.getcwd())
template_path = os.path.join(os.path.dirname(__file__), 'templates', 'register.html')
print("Template path:", template_path)
print("Template Exists:", os.path.exists(template_path))

# Flask app setup
app = Flask(__name__, template_folder='templates')

@app.route('/')
def register():
    return render_template('register.html')

@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        return render_template('success.html', name=name)

if __name__ == '_main_':
    app.run(debug=True)